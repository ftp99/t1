module Compass
  class Error < Sass::SyntaxError
  end
end

