module Compass
  module Core
    VERSION = "1.0.1"
  end
end
