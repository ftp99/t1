module Compass
  VERSION = "1.0.1"
  VERSION_NAME = "Polaris"
end
