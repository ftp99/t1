/**
 * main page dom events init
 */

'use strict';

require('./project.js');
require('./filelist.js');
require('./options.js');
require('./windows.js');